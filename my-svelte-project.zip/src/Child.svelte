<svelte:options accessors={true}/>
<script lang="ts">
	import { onMount } from "svelte";
	export let value;
	export let reset;
	export let selected = false;
	let ref;
	let isCtrlKey;

	const onInput = e => {
		if(e.relatedTarget?.classList.contains('ctrl-active')) {
			selected = true;
			isCtrlKey = false;
		} else {
			selected = false;
			isCtrlKey = false;
			reset();
		}
		value = parseFloat(e.target.innerText)
	}
	const onFocus = ev => {
		selected = true;
		if(isCtrlKey) {
			
		}
	}
	const ctrlKey = ev => {
		if (ev.ctrlKey) {
			isCtrlKey = true;
		} else {
			isCtrlKey = false;
		}
	}
</script>

<div class:selected class:ctrl-active={isCtrlKey} class="item" contenteditable="true" bind:this={ref} on:blur={onInput} on:focus={onFocus} on:mousedown={ctrlKey} on:mouseup={ctrlKey}>{value}</div>


<style>
	.item {
		box-sizing: border-box;
		width: 100%;
		border: 1px solid;
	}
	.item:focus-visible {
		/* border: none; */
		outline:  none;
	}
	.item.selected {
		border: 1px solid red;
		background-color: rgba(255, 0, 0, .1)
		
	}

	.item.ctrl-active {
		border: 3px solid red;
		background-color: rgba(255, 0, 0, .1)
	}

</style>