<script lang="ts">
	import { onMount } from 'svelte';
	import Child from './Child.svelte';
	let name: string = 'Nelson';
	let inputs = creatObj(8);
	let _refs = []
	$: storeValue1 = 1;
	$: storeValue2 = 2 + storeValue1;
	function creatObj(count) {
		const p = [];
		for(let i = 0; i < count; i++) {
			p.push(
				{
					item: i,
					key: i,
					value: 0
				}
			);
		}
		return p;
	}
	const resetList = () => {
		for(let item of  _refs) {
			item.selected = false;
		}
	}
</script>

<main>
	<h1>Hello {name}!</h1>
	<div style="display: flex; width: 100%">
		{#each inputs as input, i}
			<Child reset={resetList} bind:this={_refs[i]} bind:value={input.value}/>
		{/each}
	</div>
</main>

<style>
	main {
		text-align: center;
		padding: 1em;
		max-width: 240px;
		margin: 0 auto;
	}

	h1 {
		color: #ff3e00;
		text-transform: uppercase;
		font-size: 4em;
		font-weight: 100;
	}

	@media (min-width: 640px) {
		main {
			max-width: none;
		}
	}
</style>